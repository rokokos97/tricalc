import React from 'react';
import {Route, Routes} from 'react-router';
import Main from './components/main';
import RunCalculatorMobile from './components/runCalculatorMobile';
import SwimCalculatorMobile from './components/swimCalculatorMobile';
import TriCalculatorMobile from './components/triCalculatorMobile';
function App() {
  return (
    <div>
      <Routes>
        <Route index element={<Main/>}/>
        <Route path={'/run'} element={<RunCalculatorMobile/>}/>
        <Route path={'/swim'} element={<SwimCalculatorMobile/>}/>
        <Route path={'/tri'} element={<TriCalculatorMobile/>}/>
      </Routes>
    </div>
  );
}
export default App;
