## About Pace Calculator App

This app is designed for people who want to improve their results!

## Technologies and libraries:

## ReactJS
<p> 
    <a href="https://react.dev/">
        <img src="https://upload.wikimedia.org/wikipedia/commons/a/a7/React-icon.svg" alt="React.js logo" height="140">
    </a>
</p>
<p>  
    The library for web and native user interfaces.
</p>

| [Docs](https://react.dev/learn) | [Quick start](https://react.dev/learn/installation) |

## ant.designe
<p> 
    <a href="https://ant.design/">
        <img src="https://www.specbee.com/sites/default/files/inline-images/Ant.png" alt="React.js logo" height="140">
    </a>
</p>
<p>  
    Help designers/developers building beautiful products more flexible and working with happiness

</p>

| [Git Docs](https://github.com/ant-design/ant-design) | [Getting started](https://ant.design/components/overview/) |
